<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="images/gioithieu/logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" type="text/css" href="footer.css">
</head>
<footer>
<div class="container-footer">
    <div class="footer-content container">
        <div class="footer-info">
            <div class="float-left">
                <i class="icon-riviu-footer float-left"></i>
                <div class="text-normal-black text-nowrap">Ăn khắp nơi chơi khắp chốn</div>
            </div> 
            <div class="float-right">
                <a href="" class="">
                    <h4 class="text-item-hover">Về chúng tôi</h4>
                </a> 
                <a href="lienhe.php" target="_blank" class="">
                    <h4 class="text-item-hover">Liên hệ</h4>
                </a> <a href="chinhsach.php" target="_blank" class="">
                    <h4 class="text-item-hover">Chính sách</h4>
                </a>
            </div>
        </div>
        <div class="line"></div>
        <div class="footer-description text-normal-gray">© Công Ty TNHH RIVICO  •  Địa chỉ: 372-374 Trần Hưng Đạo, Phường 2, Quận 5, HCM  •  Số điện thoại: 091 5650550  •  Mã số thuế: 0316141166 
    Giấy phép thiết lập MXH số 528/GP-BTTTT , Ký ngày : 17/11/2020 cấp bởi Bộ thông tin và truyển thông • Email: contact@riviu.vn 
    • Người chịu trách nhiệm nội dung: Lê Đình Thái</div>
</div> 
</footer>
