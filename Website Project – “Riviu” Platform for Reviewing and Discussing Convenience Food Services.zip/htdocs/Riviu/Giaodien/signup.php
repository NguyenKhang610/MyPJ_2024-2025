<?php
    //Import PHPMailer classes into the global namespace
    //These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
 
    //Load Composer's autoloader
    require 'vendor/autoload.php';
 
    if (isset($_POST["register"]))
    {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $password = $_POST["password"];
 
        //Instantiation and passing `true` enables exceptions
        $mail = new PHPMailer(true);
 
        try {
            //Enable verbose debug output
            $mail->SMTPDebug = 0;//SMTP::DEBUG_SERVER;
 
            //Send using SMTP
            $mail->isSMTP();
 
            //Set the SMTP server to send through
            $mail->Host = 'smtp.gmail.com';
 
            //Enable SMTP authentication
            $mail->SMTPAuth = true;
 
            //SMTP username
            $mail->Username = 'your_email@gmail.com';
 
            //SMTP password
            $mail->Password = 'your_password';
 
            //Enable TLS encryption;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
 
            //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
            $mail->Port = 587;
 
            //Recipients
            $mail->setFrom('your_email@gmail.com', 'your_website_name');
 
            //Add a recipient
            $mail->addAddress($email, $name);
 
            //Set email format to HTML
            $mail->isHTML(true);
 
            $verification_code = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
 
            $mail->Subject = 'Email verification';
            $mail->Body    = '<p>Your verification code is: <b style="font-size: 30px;">' . $verification_code . '</b></p>';
 
            $mail->send();
            // echo 'Message has been sent';
 
            $encrypted_password = password_hash($password, PASSWORD_DEFAULT);
 
            // connect with database
            $conn = mysqli_connect("localhost:8889", "root", "root", "test");
 
            // insert in users table
            $sql = "INSERT INTO users(name, email, password, verification_code, email_verified_at) VALUES ('" . $name . "', '" . $email . "', '" . $encrypted_password . "', '" . $verification_code . "', NULL)";
            mysqli_query($conn, $sql);
 
            header("Location: email-verification.php?email=" . $email);
            exit();
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="loginstyle.css">
	<script>
		/*Chèn Fontawesome dô nghen:  https://kit.fontawesome.com/a076d05399.js*/

		var input = document.querySelector('.pswrd');
		var show = document.querySelector('.show');
		show.addEventListener('click', active);
		function active(){
			if(input.type === "password"){
				input.type = "text";
				show.style.color = "#1DA1F2";
				show.textContent = "HIDE";
			}else{
				input.type = "password";
				show.textContent = "SHOW";
				show.style.color = "#111";
			}
		}
	
	</script>
</head>
<body>
    <div class="container">
		<header>Đăng ký</header>
		<form action="" method="POST">
			<div class="input-field">
				<input type="text" name="email" required>
				<label>Email</label>
			</div>
			<div class="input-field">
				<input class="pswrd" type="password" name="password" required>
				<span class="show">SHOW</span>
				<label>Mật khẩu</label>
			</div>
			<div class="input-field">
				<input class="pswrd" type="password" name="rpassword" required>
				<span class="show">SHOW</span>
				<label>Xác nhận mật khẩu</label>
			</div>
			<div class="input-field">
				<input type="text" name="name" required>
				<label>Tên người dùng</label>
			</div>
			<div class="button">
				<div class="inner">
				</div>
				<button type="submit" name="re">Đăng ký</button>
			</div>
		</form>
		
		<div class="signup"> Đã có tài khoản?
			<a href="login.html">Đăng nhập</a>
		</div>
	</div>
</body>
</html>