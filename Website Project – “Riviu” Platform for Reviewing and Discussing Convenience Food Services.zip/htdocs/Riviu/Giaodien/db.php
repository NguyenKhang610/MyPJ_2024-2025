<?php
session_start();
$conect = mysqli_connect('localhost','root','','doantienloi');
if($conect)
{
    mysqli_query($conect, "Set NAMES 'UTF8'");
}
else{
    echo "Kết nối thất bại";
}
?>