<?php
    $conect = mysqli_connect('localhost','root','','doantienloi');
    if($conect)
    {
        mysqli_query($conect, "Set NAMES 'UTF8'");
    }
    else{
        echo "Kết nối thất bại";
    }
?>
<?php
include 'header.php';
$id = $_SESSION["ID_DANGNHAP"];
$sql = "SELECT * FROM account WHERE ID_DANGNHAP='$id'";
$query = mysqli_query($conect, $sql);
$row = mysqli_fetch_assoc($query);
$sql_bv = "SELECT * FROM quanlybaidang WHERE ID_NGUOIDANG='$id' ORDER BY ID_BAIDANG DESC" ;
$query_bv = mysqli_query($conect, $sql_bv);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang thông tin cá nhân - Riviu</title>
    <link rel="stylesheet" href="trangthongtin.css">
    <link rel="stylesheet" href="chinhsach.css">
    <script src="trangthongtin.js"></script>
    <link rel="stylesheet" href="test1.css">
</head>
<body style="margin-top: 70px; background-color:#F8F9FA">
    <div class="container" style="background-color: white;">
        <div class="khung">
        <div class="profile-header">
            <div class="profile-avatar">
                <img src="trangphu/Ảnh/<?php echo $row['ANH']; ?>" alt="Ảnh"  class="avatar">
            </div>

            <div class="profile-info">
                <h1 class="profile-name" style="color:black"><?php echo $row['HOTEN']; ?></h1>
                <p class="profile-username" style="color:black"><?php echo $row['EMAIL']; ?></p>
            </div>   
        </div>

        <div class="profile-stats">
            <div class="profile-stat">
                <span class="stat-number" style="color:black">2</span>
                <span class="stat-label" style="color:black">Bài viết</span>
            </div>
        </div>
        <br>
        <div class="profile-description">
            <p style="color:black">Review chất lượng đến từ <?php echo $row["HOTEN"]; ?>, tìm hiểu thêm tại Riviu.vn</p>
        </div>

        <div class="profile-content">
            <div class="tab-container">
                <ul class="tab-list">
                    <li class="tab-item"><button id="btnContent" style="background-color:white; font-size:25px;" onclick="transform('baiviet')">Bài viết</button></li>
                    <li class="tab-item"><button id="btnPicture" style="background-color:white; font-size:25px;" onclick="transform('anh')">Ảnh</button></li>
                </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="baiviet">
                    <div class="">
                        <div class="">
                            <div class="  g-4" style="margin-left:30px;
                            margin-right:30px;  ">
                                <div class="lm" style="display:flex;
                                flex-wrap: wrap;
                                gap:10px;
                                justify-content:left;">
                                <?php
                                 while ($row_bv = mysqli_fetch_assoc($query_bv)) {
                                    
                                    ?>
                                    
                                    <div class="bd">
                                        <div class=" " data-aos="zoom-out-right">
                                            <a data-fancybox="gallery" href="baivietmau.php?page_layout=baivietmau&id=<?php echo $row_bv['ID_BAIDANG']; ?>" data-src="trangphu/Ảnh/<?php echo $row_bv["ANH_BAIDANG"] ?>">
                                                <img alt="" class="img-fluidz1 " style="width:220px;
                                                height:220px;
                                                border-radius: 5% 5% 0 0;" src="trangphu/Ảnh/<?php echo $row_bv["ANH_BAIDANG"] ?>" >
                                            </a>
                                        </div>
                                        <h1 style="color:black;font-weight:bold;margin-left:10px; font-size:20px; width: 200px; line-height: 1.1; font-family:'Times New Roman', Times, serif; text-align:left"><?php echo $row_bv["TIEUDE_BAIDANG"]?> </h1>
                                        <div style="display: flex; flex-wrap: wrap;">
                                            <div style="margin-left:20px;">
                                            <img  src="trangphu/Ảnh/<?php echo $row['ANH']; ?>" style="width: 30px; height: 30px ;clip-path: circle(15px at 50% 50%);">
                                            
                                            </div>
                                            <div style="margin-top:12PX; margin-left: 10px; margin-bottom: 20px;">
                                                <span style="font-size:15px"><?php echo $row['HOTEN']; ?></span>
                                            </div>
                                        </div>
                
                                    </div>
                                <?php } ?>
                                    
                                
                                </div>
                            </div>
                            
                        </div>
                    </div>
            </div>
        </div>
    </div>  
                </div>
                <div class="tab-pane" id="anh">
                    <div>
                    <div class="">
        <div class="">
            <div class="  g-3">
                <div class="ll">
                <div class="">
                    <div class=" " data-aos="zoom-out-right">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/01.jpg">
                            <img alt="" class="img-fluidz " src="trangphu/Ảnh/01.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-down">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/02.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/02.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-down">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/03.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/03.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-left">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/04.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/04.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-right">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/05.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/05.jpg" >
                        </a>
                    </div>
                    <div>
                        
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-up">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/06.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/06.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-up">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/07.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/07.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-left">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/08.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/08.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-right">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/09.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/09.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-up">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/10.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/10.jpg" >
                           
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-up">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/11.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/11.jpg" >
                        </a>
                    </div>
                </div>
                <div class="">
                    <div class=" " data-aos="zoom-out-left">
                        <a data-fancybox="gallery" data-src="trangphu/Ảnh/12.jpg">
                            <img alt=""  class="img-fluidz " src="trangphu/Ảnh/12.jpg" >
                        </a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
  