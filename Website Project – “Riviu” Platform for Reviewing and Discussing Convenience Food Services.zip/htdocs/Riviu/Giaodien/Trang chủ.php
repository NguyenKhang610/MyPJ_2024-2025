<?php
require_once "header.php";
$conect = mysqli_connect('localhost','root','','doantienloi');
if($conect)
{
    mysqli_query($conect, "Set NAMES 'UTF8'");
}
$sql_dm = "SELECT * FROM quanlydanhmuc";
$query_dm = mysqli_query($conect, $sql_dm);
$sql_bv = "SELECT * FROM quanlybaidang" ;
$query_bv = mysqli_query($conect, $sql_bv);
$sql = "SELECT * FROM account WHERE ID_DANGNHAP='$id'";
$query = mysqli_query($conect, $sql);
$row = mysqli_fetch_assoc($query);

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" >
    <title>Riviu</title>
    <link rel="stylesheet" href="Trang chủ.css">
<body>
	<div id="DIV_1076">
		<div id="DIV_1077">
			<div id="DIV_1078">
				<div id="DIV_1079">
					<div id="DIV_1">
						<div id="DIV_2">
							<div id="DIV_3">
								<div id="DIV_4">
									<div id="DIV_5">
										<div id="DIV_6">
											<div id="DIV_7">
												<div id="DIV_8">
													<div id="DIV_9">
														<div id="DIV_10">
															<div id="DIV_11">
																<img alt="Banner Contact" src="https://static.riviu.co/image/2022/10/11/0b8e06bde3e3f608290fe321039e9f64.png" id="IMG_12" />
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div id="DIV_13">
									<div id="DIV_14">
										<h1 id="H1_15">
											Dành cho bạn
										</h1>
										<!-- Dành cho bạn -->
	
									<!-- Dành cho bạn-->
	
									<div id="DIV_183">
										<ul id="UL_184">
											<li id="LI_185">
												<h3 id="H3_186">
													Tất cả
												</h3>
											</li>
											<?php while($row_dm = mysqli_fetch_assoc($query_dm)) {
												?><li id="LI_187">
												<h3 id="H3_188">
												<?php echo $row_dm["TEN_DANHMUC"] ?>
												</h3>
											</li>
											<?php } ?>
											
											
									</div>
									<div id="DIV_201">
									</div>
									<!---bài viết-->
									<div class="tab-pane active" id="baiviet">
                    <div class="">
                        <div class="">
                            <div class="  g-4" style="margin-left:30px;
                            margin-right:30px;  ">
                                <div class="lm" style="display:flex;
                                flex-wrap: wrap;
                                gap:10px;
                                justify-content:left;">
                                <?php
                                 while ($row_bv = mysqli_fetch_assoc($query_bv)) {
                                    
                                    ?>
                                    
                                    <div class="bd">
                                        <div class=" " data-aos="zoom-out-right">
                                            <a data-fancybox="gallery" href="baivietmau.php?page_layout=baivietmau&id=<?php echo $row_bv['ID_BAIDANG']; ?>" data-src="trangphu/Ảnh/<?php echo $row_bv["ANH_BAIDANG"] ?>">
                                                <img alt="" class="img-fluidz1 " style="width:220px;
                                                height:220px;
                                                border-radius: 5% 5% 0 0;" src="trangphu/Ảnh/<?php echo $row_bv["ANH_BAIDANG"] ?>" >
                                            </a>
                                        </div>
                                        <h1 style="color:black;font-weight:bold;margin-left:10px; font-size:20px; width: 200px; line-height: 1.1; font-family:'Times New Roman', Times, serif; text-align:left"><?php echo $row_bv["TIEUDE_BAIDANG"]?> </h1>
                                        <div style="display: flex; flex-wrap: wrap;">
                                            <div style="margin-left:20px;">
                                            <img  src="trangphu/Ảnh/<?php echo $row['ANH']; ?>" style="width: 30px; height: 30px ;clip-path: circle(15px at 50% 50%);">
                                            
                                            </div>
                                            <div style="margin-top:12PX; margin-left: 10px; margin-bottom: 20px;">
                                                <span style="font-size:15px"><?php echo $row['HOTEN']; ?></span>
                                            </div>
                                        </div>
                
                                    </div>
                                <?php } ?>
                                    
                                
                                </div>
                            </div>
                            
                        </div>
                    </div>
            </div>
        </div>
    </div>  
										<!--kết thúc bài viết-->
	
									</div>
							
									<!---->
	
									<!---->
	
								</div>
							</div>
							
											<!---->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
</body>
<?php
include "footer.php";
?>
								
								
