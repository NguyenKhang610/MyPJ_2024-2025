document.addEventListener('DOMContentLoaded', (event) => {
    const textInput = document.getElementById('textInput');
    const submitIcon = document.getElementById('submitIcon');
    const form = document.getElementById('myForm');

    // Show the submit icon when the input is focused
    textInput.addEventListener('focus', () => {
        submitIcon.style.display = 'block';
        textInput.classList.add('input-focused');
    });

    // Hide the submit icon when the input is blurred
    textInput.addEventListener('blur', () => {
        submitIcon.style.display = 'none';
        textInput.classList.remove('input-focused');
    });

    // Submit the form when the submit icon is clicked
    submitIcon.addEventListener('click', () => {
        form.submit();
    });
});