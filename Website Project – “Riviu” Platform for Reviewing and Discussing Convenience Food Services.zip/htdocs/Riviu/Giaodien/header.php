<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riviu</title>
    <link rel="shortcut icon" type="image/png" href="images/gioithieu/logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" type="text/css" href="header.css">
    <script src="https://kit.fontawesome.com/yourcode.js"></script>
</head>


<body>

<!-- Header -->
<?php

session_start();
$conect = mysqli_connect('localhost','root','','doantienloi');
if($conect)
{
    mysqli_query($conect, "Set NAMES 'UTF8'");
}
ob_start();
$id=$_SESSION['ID_DANGNHAP'];
$sql = "SELECT * FROM account WHERE ID_DANGNHAP='$id'";
$query = mysqli_query($conect, $sql);
$row = mysqli_fetch_assoc($query);
if(!isset($_SESSION['ID_DANGNHAP'])) {
    ?>
    <header class="container-fluid"> 
        <div class="header container-header">
            <div>
                <div id="menu" class="menu" style="background-color: white;">
                    <div id="logo"><a href="Trang chủ.php"><img width="90px" height="50px" src="trangphu/Ảnh/logo.png"></a></div>                            
                    <ul>
                                <a class="anew" href="login.php">Đăng nhập</a>
                                <a class="anew" href="lienhe.php">Liên hệ</a>
                    </ul>
                </div>
                <div><input type="text" autocomplete="off" placeholder="Tìm kiếm Riviu, địa điểm,..." id="INPUT_16" />
                
                    <div id="icon">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </div></div>
            </div>
        </div>               
    <?php }
    else
    { ?>
</header>
<header class="container-fluid">
<div class="header container-header">
    <div>
        <div id="menu" class="menu" style="background-color: white;">
            <div id="logo"><a href="Trang chủ.php"><img width="90px" height="50px" src="trangphu/Ảnh/logo.png"></a></div>                            
            <ul>
                        <a class="anew" href="vietbai.php">Viết bài</a>
                        <a href="trangthongtin.php"> <img src="trangphu/Ảnh/<?php echo $row['ANH']; ?>" style="width:42px; height:42px; clip-path: circle(21px at 50% 50%);"> </a>                        
                        <a style="margin-left:10px;" class="anew" href="lienhe.php">Liên hệ</a>
                        <a style="margin-left:3px;" class="anew" href="logout.php">Đăng xuất</a>
            </ul>
        </div>
        <div><input  type="text" autocomplete="off" placeholder="Tìm kiếm Riviu, địa điểm,..." id="INPUT_17" />
        
            <div id="icon1">
                <i class="fa-solid fa-magnifying-glass"></i>
            </div></div>
    </div>
</div>
</header>
<?php } ?>
</body>