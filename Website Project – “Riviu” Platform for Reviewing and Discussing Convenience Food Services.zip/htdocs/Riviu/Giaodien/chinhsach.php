
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chính sách bảo mật | Riviu App</title>
  <link rel="stylesheet" href="chinhsach.css">
</head>
<body style="margin-top:100px;">

  <main style="width:100%;">
    <div>
      <p class="p1">Chính sách bảo mật</p>
    
      <div class="language-switcher change" style="margin-top:70px;">
          <button id="btn-english" onclick="switchLanguage('english')">EN</button>
          <button id="btn-vietnamese" onclick="switchLanguage('vietnamese')">VN</button>
      </div>
    </div>
  
 
    <div id = "vietnamese">
      <section class="section1">
        <h2>Quyền thu thập và sử dụng thông tin</h2>
        <p>
          Khi bạn truy cập và sử dụng, Riviu App có thể thu thập và lưu trữ các thông tin như số liệu thống kê quá trình truy cập, thông tin cá nhân cung cấp cho Riviu App khi đăng nhập. Chúng tôi có thể sử dụng các thông tin này vào việc lập kế hoạch, nghiên cứu, thiết kế và giới thiệu các dịch vụ, phát triển và tối ưu hoá ứng dụng trên website hoặc trên điện thoại; cung cấp thông tin cho các cơ quan chức năng theo quy định của pháp luật.
        </p>
      </section>

      <section class="section2">
        <h2>Riviu App chia sẻ thông tin như thế nào?</h2>
        <p>
          Riviu App chỉ chia sẻ thông tin người dùng khi được sự cho phép để thực hiện các yêu cầu của họ, ngoại trừ những trường hợp cần thiết.
        </p>
        <p>
          Riviu App có thể hợp tác với các công ty khác để cùng thực hiện việc cung cấp các sản phẩm và dịch vụ của mình. Nếu bạn quan tâm đến những sản phẩm hoặc dịch vụ liên kết của Riviu App, chúng tôi có thể chia sẻ thông tin khác có liên quan với sản phẩm của các đối tác đó. Riviu App không kiểm soát việc các đối tác kinh doanh của mình sử dụng thông tin chúng tôi thu thập. Việc sử dụng những thông tin này được quy định trong Chính sách bảo mật của các đối tác đó. Tuy nhiên, Riviu App sẽ không chia sẻ thông tin cá nhân với các đối tác thương mại của mình trừ khi bạn cho phép việc chia sẻ thông tin này.
        </p>
      </section>

      <section class="section3">
        <h2>Thu thập và bảo vệ thông tin người dùng</h2>
        <p>
          Thông tin cá nhân của Khách hàng trên Riviu App được Riviu App cam kết bảo mật tuyệt đối theo chính sách bảo vệ thông tin cá nhân của Riviu App. Việc thu thập và sử dụng thông tin của mỗi Khách hàng chỉ được thực hiện khi có sự đồng ý của Khách hàng đó, trừ những trường hợp pháp luật có quy định khác. Riviu App cam kết:
        </p>
        <ul>
          <li>Không sử dụng, không chuyển giao, cung cấp hay tiết lộ cho bên thứ ba nào về thông tin cá nhân của Khách hàng khi không có sự cho phép hoặc đồng ý từ Khách hàng, trừ những trường hợp pháp luật có quy định khác.</li>
          <li>Trong trường hợp máy chủ lưu trữ thông tin bị hacker tấn công dẫn đến mất mát dữ liệu cá nhân Khách hàng, Riviu App sẽ có trách nhiệm thông báo vụ việc cho cơ quan chức năng điều tra xử lý kịp thời và thông báo cho Khách hàng được biết.</li>
          <li>Bảo mật tuyệt đối mọi thông tin giao dịch trực tuyến của Khách hàng bao gồm thông tin hóa đơn, chứng từ kế toán số hóa tại khu vực dữ liệu trung tâm an toàn của Riviu App.</li>
        </ul>
        <p>
          Riviu App có thể thường xuyên gửi email cho người dùng để thông báo về các tính năng mới, nhận phản hồi thông tin sử dụng, thông báo về những thay đổi cần thiết, hoặc để bạn có thể cập nhật kịp thời những thông tin mới nhất từ Riviu App.
        </p>
        <p>Ứng dụng Riviu App trên di động sử dụng “Push notification” để thông báo đến người dùng việc phát triển các ứng dụng của Riviu App. Bạn có thể từ chối nhận những thông tin này bằng cách chỉnh sửa trong ứng dụng trên điện thoại di động.</p>
      </section>

      <section class="section4">
          <h2>Người sử dụng có thể cập nhật và thay đổi thông tin như thế nào?</h2>
          <p>
              Khách hàng có quyền tự kiểm tra, cập nhật, điều chỉnh thông tin cá nhân của mình bằng cách đăng nhập vào tài khoản và chỉnh sửa thông tin cá nhân hoặc yêu cầu Riviu App thực hiện việc này.
          </p>
          <p>
              Thông tin cá nhân của khách hàng sẽ được lưu trữ cho đến khi khách hàng có yêu cầu hủy bỏ hoặc khách hàng tự đăng nhập và thực hiện hủy bỏ. Trong mọi trường hợp thông tin cá nhân của khách hàng sẽ được bảo mật trên máy chủ của Riviu App.
          </p>
      </section>

      <section class="section5">
          <h2>Quyền của bạn đối với việc xóa Thông tin Cá nhân</h2>
          <p>Theo luật và quy định hiện hành, bạn có quyền:</p>
          <ul>
              <li>Rút lại sự động ý cho phép thu thập, sử dụng hoặc tiết lộ dữ liệu cá nhân</li>
              <li>Xoá dữ liệu cá nhân (trong một số trường hợp)</li>
          </ul>
          <p>
              Nếu bạn muốn đưa ra yêu cầu thực hiện các quyền của mình, bạn có thể liên hệ với chúng tôi bằng cách gửi email cho Bộ phận Chăm Sóc Khách Hàng của chúng tôi tại địa chỉ email contact@riviu.vn .Chúng tôi sẽ xử lý các yêu cầu này theo Chính Sách Bảo Mật cũng như quy định pháp luật có liên quan.
          </p>
          <p>
              Tuy nhiên, chúng tôi sẽ lưu trữ và sử dụng thông tin người sử dụng nếu điều đó là cần thiết để thực hiện các nghĩa vụ theo quy định của pháp luật, để giải quyết tranh chấp, và đảm bảo các thỏa thuận của chúng tôi trừ khi pháp luật có quy định khác.
          </p>
      </section>
    
      <section class="section6">
          <h2>Thông tin liên hệ của Riviu App</h2>
          <p>Công ty TNHH Rivico</p>
          <p>Trụ sở chính: 372 Trần Hưng Đạo, Phường 2, Quận 5, TP Hồ Chí Minh</p>
          <p>Hotline: 098 2020 575</p>
          <p>Email: thai@riviu.vn</p>
      </section>

      <section class="section7">
          <h2>Những quy định khác</h2>
          <p>Tất cả các quy định trên sẽ bị chi phối và được hiểu theo luật pháp Việt Nam. Chúng tôi có quyền sửa đổi các quy định này vào bất kỳ thời điểm nào và các sửa đổi đó sẽ có hiệu lực ngay tại thời điểm được được đăng tải tại Riviu.vn
          </p> 
      </section>
    </div>
    
    <div id ="english">
      <section class="section1">
        <h2>Right to collect and use information</h2>
        <p>
          When you access and use, Riviu App may collect and store information such as access statistics, personal information provided to Riviu App when logging in. We may use this information to plan, research, design and recommend services, develop and optimize applications on the website or on the phone; provide information to the authorities in accordance with the law.
        </p>
      </section>

      <section class="section2">
        <h2>How does Riviu App share information?</h2>
        <p>
          Riviu App only shares user information when authorized to fulfill their requests, except in necessary cases.
        </p>
        <p>
          Riviu App may cooperate with other companies to jointly deliver its products and services. If you are interested in Riviu App's affiliated products or services, we may share other information relevant to those partners' products. Riviu App has no control over how our business partners use the information we collect. The use of this information is regulated in the Privacy Policy of those partners. However, the Riviu App will not share personal information with its commercial partners unless you authorize this sharing.
        </p>
      </section>

      <section class="section3">
        <h2>Collection and protection of user information</h2>
        <p>
          Personal information of customers on Riviu App is absolutely guaranteed by Riviu App according to Riviu App's personal information protection policy. The collection and use of information of each Customer is done only with the consent of that Customer, unless otherwise provided for by law. Riviu App is committed to:
        </p>
        <ul>
          <li>Do not use, transfer, provide or disclose to any third party the Customer's personal information without the consent or consent of the Customer, unless otherwise provided by law.</li>
          <li>In case the information server is attacked by hackers leading to the loss of Customer's personal data, Riviu App will be responsible for notifying the incident to the investigating authorities for timely handling and notifying the Customer. goods are known.</li>
          <li>Absolutely secure all information of customers' online transactions including invoice information, digital accounting documents in the secure central data area of Riviu App</li>
        </ul>
        <p>
          The Riviu App may regularly email users to notify you of new features, receive usage feedback, notify you of necessary changes, or to keep you up to date with new information. Best from Riviu App.</p>
        <p>The Riviu App mobile application uses “Push notification” to notify users of the development of Riviu App applications. You can opt out of receiving this information by editing it in the mobile app.</p>
      </section>

      <section class="section4">
          <h2>How can users update and change information?</h2>
          <p>
            Customers have the right to check, update and adjust their personal information by logging in to their account and editing personal information or requesting Riviu App to do this.
          </p>
          <p>
            The customer's personal information will be stored until the customer has a request to cancel or the customer manually logs in and cancels. In all cases, customer's personal information will be kept confidential on the server of Riviu App.
          </p>
      </section>

      <section class="section5">
          <h2>Your right to the deletion of Personal Information</h2>
          <p>Subject to applicable laws and regulations, you have the right to:</p>
          <ul>
              <li>Withdraw consent to the collection, use or disclosure of personal data</li>
              <li>Erase personal data (in some cases)</li>
          </ul>
          <p>
            If you wish to make a request to exercise your rights, you may contact us by emailing our Customer Care Department at contact@riviu.vn. We handle these requests in accordance with the Privacy Policy and relevant laws.
          </p>
          <p>
            If you wish to make a request to exercise your rights, you may contact us by emailing our Customer Care Department at contact@riviu.vn. We handle these requests in accordance with the Privacy Policy and relevant laws.
          </p>
      </section>
    
      <section class="section6">
          <h2>Riviu App Contact Information</h2>
          <p>Rivico Co., Ltd</p>
          <p>Head office: 372 Tran Hung Dao, Ward 2, District 5, Ho Chi Minh City</p>
          <p>Hotline: 098 2020 575</p>
          <p>Email: thai@riviu.vn
          </p>
      </section>

      <section class="section7">
          <h2>Other regulations</h2>
          <p>All of the above provisions shall be governed by and construed in accordance with the laws of Vietnam. We reserve the right to amend these regulations at any time and such amendments will take effect immediately at the time they are posted at Riviu.vn
          </p>
      </section>
    </div>
      

    </div>
    <script src="chinhsach.js"></script>
  </main>
</body>
</html>
<?php
require_once 'footer.php';
?>
