<?php
session_start();

if(isset($_SESSION['ID_DANGNHAP']) )
{
    unset($_SESSION['ID_DANGNHAP']);
}
header('location:Trang chủ.php')
?>