<?php
include 'db.php';
include 'header.php';
$id = $_SESSION["ID_DANGNHAP"];
$sql = "SELECT * FROM account WHERE ID_DANGNHAP='$id'";
$query = mysqli_query($conect, $sql);
$row = mysqli_fetch_assoc($query);
$sql_danhmuc = "SELECT * FROM quanlydanhmuc";
$query_danhmuc = mysqli_query($conect, $sql_danhmuc);
?>
<?php
    $sql_mg = "SELECT * FROM quanlybaidang";
    $query_mg = mysqli_query($conect, $sql_mg);

    if(isset($_POST['sbm'])){
        $tieude = $_POST['TIEUDE_BAIDANG'];

        $image = $_FILES['ANH_BAIDANG']['name'];
        $image_tmp = $_FILES['ANH_BAIDANG']['tmp_name'];

        $noidung = $_POST['NOIDUNG_BAIDANG'];
        $ngay = date('Y-m-d');
        $gio = date('H:i');
        $danhgia = $_POST['star'];

        $sql_add = "INSERT INTO quanlybaidang (TIEUDE_BAIDANG,NOIDUNG_BAIDANG,ANH_BAIDANG,NGAY_BAIDANG,GIO_BAIDANG, DANHGIA,ID_NGUOIDANG)
        VALUES ('$tieude', '$noidung', '$image','$ngay','$gio', '$danhgia', '$id')";
        $query_add = mysqli_query($conect, $sql_add);
        move_uploaded_file($image_tmp, 'E:/xampp/htdocs/Riviu/Giaodien/trangphu/Ảnh/'.$image);
        header('location: quanlyvietbai.php?page_layout=Vietbai');

    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <title>Riviu - Viết bài review</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Vietbai.css">
    <link rel='stylesheet prefetch' href='https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css'>
    <script>
      function chooseFile(fileInput){
        if(fileInput.files && fileInput.files[0]){
          var reader = new FileReader();

          reader.onload = function (e){
            $('#image').attr('src',e.target.result);
          }
          reader.readAsDataURL(fileInput.files[0]);
        }
      }
    </script>
</head>
<body>
    <div id="main">
      <div class="riviu-container" style="min-height:calc(100vh - 366px);" data-v-a81ebbe4>

        <form action="" method="POST" enctype="multipart/form-data">
        <div class="write-container" data-v-a81ebbe4>
            <div class="left-content" data-v-a81ebbe4>
                <div class="btn-block" data-v-a81ebbe4>
                  <div class="btn-active text-normal-black" data-v-a81ebbe4 style="cursor: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABWJJREFUWEfFlltsk2UYx//v935tabexdps7tes21829bYYXEsIFkeiN8QZQhocbiIkSCcYLI9HEqIk3JqjRgOIBvfCGGEMUFA8xMTMY0YtlYbh+7cSF7sTaLaPbuh7Xfq95PvotZUDSopvvzXd68zy/5/8+h4/h+joG4EUAueLzhl1Y0dMMgN8BPLHRECbANIBWAGcAPL6REGsBSJCzRYjsRpyDCTAFwF3icMMgTIBJAJ41EX8LYB+AdVXCBJgA0HYLyc8VITLrdRwmwDgA722cfAegH8C6QJgAEQDtRQANwFzxXhavlBPvrYcKJsAVAB0AvgBw4P8owzEAPwM4BKCwHpHezqapwGEAJwCYkq/uHx4eblRV1c0557quzwkhJhlj+n8FaQLcYG8sGPRmGXuOSbkXjHUCKN03L6X8gSnKh0KIC/8W5AaAgYEBtbmx8RUw9rLNZttUW1sLh8MBi8Vi+CkUCkin01haWkIymZSQ8ivVaj3U3d1tJm3FPKsAg4ODjmqH47TC+cNNTU2oqakBY9c/S0m+pPFsviOQaDSKbDYbAWMPCSH+qti7Ka2UkoU07Wur1bq7ra0NVqsVuq4jHo8b0eZyOV1KWeCcW0gRl8tlKEN7pqenSY1xi9W6zefzzVYKYYSoadphrijvd3R0GM5pkeOrV69S+MeT6fSriUQiWVdX12azWHZJ4CWn09lCSpEy4+PjyGSzZ/1+/56KAcLhcI3U9StNTU31FFnpWlxcJJmzYOyx3t7eb8xvoVCoXur6GZfLtaO5uRmZTIYgpAQeFEL8UgkEC4VCz6icf9LV1WWcL0laV1cHu91u2CGImZkZgugXQtBsMNalS5dcVlUddns8bdXV1ZiamsJyMnlaCEEDrOxFAGddTucukpMiiUQiGUVRrB6PR6FzLoHISGCv3+//vkSJg1UOx8eUN4lEguATvULUMcby5RKwUDA42ep2ezZv3oz5+XnMzc6ekoxd4IpyzO12K1VVVYathYUFxGKxdEHXHw0EAj/Su6Ghobscdnu0u7tboRIdGxsDV1V/T09PqHwATUt7vd5NFC2V1UI8/oYIBF4PB4PPMs4/WAsRjUbTKBT2iL6+n4oJHPd1dTlVVcXo6Ci10p1+v/98JQApr9drJ4BYLIb4wsLbQogjZCA0MnJQUdUTbreblyoRjUZTEtgthBgIh0IJn89n55wbALqU9wcCgV/LBtA07e/WlpYu6nokc3Rm5jcRCOwwDWgjI09zVf2oFIL6QywWS4Kx17iivOPz+ZDP540jyBcKvr6+PhpuZS2madopZ23tky0tLaYRXdH1+3oCgYumhXAw+BTj/GRrayunjKdVhIDT6QSVYrFkZ+/p7W1mjN001G5Hw4LB4D6V8y8pCkVRMDs7i/i1axcXlpZ2bt++fakk4w8w4FO3262aEOTUnBWTk5NUhif9fv/BskIvbmKDg4OWqqqqcEN9/d0NDQ1GZyNjqVRqSJdyfyAQCK4eh6btVxj7rBSCvqVSKUxMTBR0Ke8t3V8OiNGKg8HgLq4oZ7xeL6MGRD1+bm6OciIvdZ1+VC5IKROKorQTlM1mc1HbJsWo/CKRCFby+eNCiOfLcVq6Z3UahjXtqML5EY/Hs9oFc7mc0WCy2awBRaVGkpuTkhKPOmAmk/ljk93+QGdnZ8U/rqsANBHDmvYWU5QXGhoaGM0FivBWi45peXnZKNt8Pn9+JZ/fs2XLlnil0dP+m/6IRjXtER14l3PeTt3RTDKaEysrK0a7LqqShJRHk+n0m1u3bl25E+e3BKCXly9ftuVyuX7GWD8DtgFoBKBIKRcB/AnGzlmt1s/vZP6vBf0HMZ1lP+1/xj0AAAAASUVORK5CYII=&quot;) 1 0, pointer !important;">
                        <h1>Viết bài<i class="fas fa-pencil"></i></h1>
                  </div>
                </div>
                <div class="title-block" data-v-a81ebbe4>
                  <input type="text" placeholder="Tiêu đề..." class="title-input" data-v-a81ebbe4 name="TIEUDE_BAIDANG" required>
                </div>
                <div class="content-normal-block" data-v-a81ebbe4 data-quillbot-parent="S4LmKiPtna2ey4Zx-FV6n">
                  <quillbot-extension-highlights data-element-id="S4LmKiPtna2ey4Zx-FV6n" data-element-type="text" style="display: initial; visibility: initial; opacity: initial; clip-path: initial; position: relative; float: left; top: 0px; left: 0px; z-index: 1 !important; pointer-events: none;">
                  </quillbot-extension-highlights><textarea data-v-a81ebbe4 type="text" placeholder="Bạn có gì muốn Riviu..." rows="10" class="body-review" style="width: 100%;height: 524px" data-gramm="false" wt-ignore-input="true" data-quillbot-element="S4LmKiPtna2ey4Zx-FV6n" name="NOIDUNG_BAIDANG"></textarea>
                </div>
                <div class="col-12 mb-1" style="background: #fff" data-v-a81ebbe4=>
                  <div class="d-flex title" data-v-a81ebbe4=>
                    <div class="p-2 flex-shrink-1 align-self-center label-title" data-v-a81ebbe4>
                      Danh mục
                    </div>
                    <span style="line-height: 40px; color: rgb(220, 220, 220)" data-v-a81ebbe4>|</span>
                    <div class="w-100" data-v-a81ebbe4>
                      <div tabindex="-1" class="multiselect" data-v-a81ebbe4>
                        <div class="multiselect__select sweezy-custom-cursor-hover" style="cursor: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABWJJREFUWEfFlltsk2UYx//v935tabexdps7tes21829bYYXEsIFkeiN8QZQhocbiIkSCcYLI9HEqIk3JqjRgOIBvfCGGEMUFA8xMTMY0YtlYbh+7cSF7sTaLaPbuh7Xfq95PvotZUDSopvvzXd68zy/5/8+h4/h+joG4EUAueLzhl1Y0dMMgN8BPLHRECbANIBWAGcAPL6REGsBSJCzRYjsRpyDCTAFwF3icMMgTIBJAJ41EX8LYB+AdVXCBJgA0HYLyc8VITLrdRwmwDgA722cfAegH8C6QJgAEQDtRQANwFzxXhavlBPvrYcKJsAVAB0AvgBw4P8owzEAPwM4BKCwHpHezqapwGEAJwCYkq/uHx4eblRV1c0557quzwkhJhlj+n8FaQLcYG8sGPRmGXuOSbkXjHUCKN03L6X8gSnKh0KIC/8W5AaAgYEBtbmx8RUw9rLNZttUW1sLh8MBi8Vi+CkUCkin01haWkIymZSQ8ivVaj3U3d1tJm3FPKsAg4ODjmqH47TC+cNNTU2oqakBY9c/S0m+pPFsviOQaDSKbDYbAWMPCSH+qti7Ka2UkoU07Wur1bq7ra0NVqsVuq4jHo8b0eZyOV1KWeCcW0gRl8tlKEN7pqenSY1xi9W6zefzzVYKYYSoadphrijvd3R0GM5pkeOrV69S+MeT6fSriUQiWVdX12azWHZJ4CWn09lCSpEy4+PjyGSzZ/1+/56KAcLhcI3U9StNTU31FFnpWlxcJJmzYOyx3t7eb8xvoVCoXur6GZfLtaO5uRmZTIYgpAQeFEL8UgkEC4VCz6icf9LV1WWcL0laV1cHu91u2CGImZkZgugXQtBsMNalS5dcVlUddns8bdXV1ZiamsJyMnlaCEEDrOxFAGddTucukpMiiUQiGUVRrB6PR6FzLoHISGCv3+//vkSJg1UOx8eUN4lEguATvULUMcby5RKwUDA42ep2ezZv3oz5+XnMzc6ekoxd4IpyzO12K1VVVYathYUFxGKxdEHXHw0EAj/Su6Ghobscdnu0u7tboRIdGxsDV1V/T09PqHwATUt7vd5NFC2V1UI8/oYIBF4PB4PPMs4/WAsRjUbTKBT2iL6+n4oJHPd1dTlVVcXo6Ci10p1+v/98JQApr9drJ4BYLIb4wsLbQogjZCA0MnJQUdUTbreblyoRjUZTEtgthBgIh0IJn89n55wbALqU9wcCgV/LBtA07e/WlpYu6nokc3Rm5jcRCOwwDWgjI09zVf2oFIL6QywWS4Kx17iivOPz+ZDP540jyBcKvr6+PhpuZS2madopZ23tky0tLaYRXdH1+3oCgYumhXAw+BTj/GRrayunjKdVhIDT6QSVYrFkZ+/p7W1mjN001G5Hw4LB4D6V8y8pCkVRMDs7i/i1axcXlpZ2bt++fakk4w8w4FO3262aEOTUnBWTk5NUhif9fv/BskIvbmKDg4OWqqqqcEN9/d0NDQ1GZyNjqVRqSJdyfyAQCK4eh6btVxj7rBSCvqVSKUxMTBR0Ke8t3V8OiNGKg8HgLq4oZ7xeL6MGRD1+bm6OciIvdZ1+VC5IKROKorQTlM1mc1HbJsWo/CKRCFby+eNCiOfLcVq6Z3UahjXtqML5EY/Hs9oFc7mc0WCy2awBRaVGkpuTkhKPOmAmk/ljk93+QGdnZ8U/rqsANBHDmvYWU5QXGhoaGM0FivBWi45peXnZKNt8Pn9+JZ/fs2XLlnil0dP+m/6IRjXtER14l3PeTt3RTDKaEysrK0a7LqqShJRHk+n0m1u3bl25E+e3BKCXly9ftuVyuX7GWD8DtgFoBKBIKRcB/AnGzlmt1s/vZP6vBf0HMZ1lP+1/xj0AAAAASUVORK5CYII=&quot;) 1 0, pointer !important;"></div>
                        <div class="multiselect__tags">
                          <div class="multiselect__tags-wrap" style="display:none;">
                          </div> <!----> <div class="multiselect__spinner" style="display:none;">
                          </div>
                          <select class="form-select" aria-label="Default select example" name="DANHMUC_BAIDANG">
                            <option selected>Chọn danh mục</option>
                            <?php
                              while($row_danhmuc = mysqli_fetch_assoc($query_danhmuc)){
                                ?> <option value="<?php echo $row_danhmuc['ID_DANHMUC']; ?>"><?php echo $row_danhmuc['TEN_DANHMUC'] ?></option>
                              <?php } ?>
                          </select> <!---->
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
                <div class="image-block" data-v-a81ebbe4>
                  <div class="upload-image d-flex align-items-center" data-v-a81ebbe4>
                    <div class="text-center" style="width: 100%" data-v-a81ebbe4>
                      <div data-v-a81ebbe4 class="sweezy-custom-cursor-hover" style="cursor: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABWJJREFUWEfFlltsk2UYx//v935tabexdps7tes21829bYYXEsIFkeiN8QZQhocbiIkSCcYLI9HEqIk3JqjRgOIBvfCGGEMUFA8xMTMY0YtlYbh+7cSF7sTaLaPbuh7Xfq95PvotZUDSopvvzXd68zy/5/8+h4/h+joG4EUAueLzhl1Y0dMMgN8BPLHRECbANIBWAGcAPL6REGsBSJCzRYjsRpyDCTAFwF3icMMgTIBJAJ41EX8LYB+AdVXCBJgA0HYLyc8VITLrdRwmwDgA722cfAegH8C6QJgAEQDtRQANwFzxXhavlBPvrYcKJsAVAB0AvgBw4P8owzEAPwM4BKCwHpHezqapwGEAJwCYkq/uHx4eblRV1c0557quzwkhJhlj+n8FaQLcYG8sGPRmGXuOSbkXjHUCKN03L6X8gSnKh0KIC/8W5AaAgYEBtbmx8RUw9rLNZttUW1sLh8MBi8Vi+CkUCkin01haWkIymZSQ8ivVaj3U3d1tJm3FPKsAg4ODjmqH47TC+cNNTU2oqakBY9c/S0m+pPFsviOQaDSKbDYbAWMPCSH+qti7Ka2UkoU07Wur1bq7ra0NVqsVuq4jHo8b0eZyOV1KWeCcW0gRl8tlKEN7pqenSY1xi9W6zefzzVYKYYSoadphrijvd3R0GM5pkeOrV69S+MeT6fSriUQiWVdX12azWHZJ4CWn09lCSpEy4+PjyGSzZ/1+/56KAcLhcI3U9StNTU31FFnpWlxcJJmzYOyx3t7eb8xvoVCoXur6GZfLtaO5uRmZTIYgpAQeFEL8UgkEC4VCz6icf9LV1WWcL0laV1cHu91u2CGImZkZgugXQtBsMNalS5dcVlUddns8bdXV1ZiamsJyMnlaCEEDrOxFAGddTucukpMiiUQiGUVRrB6PR6FzLoHISGCv3+//vkSJg1UOx8eUN4lEguATvULUMcby5RKwUDA42ep2ezZv3oz5+XnMzc6ekoxd4IpyzO12K1VVVYathYUFxGKxdEHXHw0EAj/Su6Ghobscdnu0u7tboRIdGxsDV1V/T09PqHwATUt7vd5NFC2V1UI8/oYIBF4PB4PPMs4/WAsRjUbTKBT2iL6+n4oJHPd1dTlVVcXo6Ci10p1+v/98JQApr9drJ4BYLIb4wsLbQogjZCA0MnJQUdUTbreblyoRjUZTEtgthBgIh0IJn89n55wbALqU9wcCgV/LBtA07e/WlpYu6nokc3Rm5jcRCOwwDWgjI09zVf2oFIL6QywWS4Kx17iivOPz+ZDP540jyBcKvr6+PhpuZS2madopZ23tky0tLaYRXdH1+3oCgYumhXAw+BTj/GRrayunjKdVhIDT6QSVYrFkZ+/p7W1mjN001G5Hw4LB4D6V8y8pCkVRMDs7i/i1axcXlpZ2bt++fakk4w8w4FO3262aEOTUnBWTk5NUhif9fv/BskIvbmKDg4OWqqqqcEN9/d0NDQ1GZyNjqVRqSJdyfyAQCK4eh6btVxj7rBSCvqVSKUxMTBR0Ke8t3V8OiNGKg8HgLq4oZ7xeL6MGRD1+bm6OciIvdZ1+VC5IKROKorQTlM1mc1HbJsWo/CKRCFby+eNCiOfLcVq6Z3UahjXtqML5EY/Hs9oFc7mc0WCy2awBRaVGkpuTkhKPOmAmk/ljk93+QGdnZ8U/rqsANBHDmvYWU5QXGhoaGM0FivBWi45peXnZKNt8Pn9+JZ/fs2XLlnil0dP+m/6IRjXtER14l3PeTt3RTDKaEysrK0a7LqqShJRHk+n0m1u3bl25E+e3BKCXly9ftuVyuX7GWD8DtgFoBKBIKRcB/AnGzlmt1s/vZP6vBf0HMZ1lP+1/xj0AAAAASUVORK5CYII=&quot;) 1 0, pointer !important;">
                        <i class="icon-photo-32 sweezy-custom-cursor-hover" data-v-a81ebbe4 style="cursor: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABWJJREFUWEfFlltsk2UYx//v935tabexdps7tes21829bYYXEsIFkeiN8QZQhocbiIkSCcYLI9HEqIk3JqjRgOIBvfCGGEMUFA8xMTMY0YtlYbh+7cSF7sTaLaPbuh7Xfq95PvotZUDSopvvzXd68zy/5/8+h4/h+joG4EUAueLzhl1Y0dMMgN8BPLHRECbANIBWAGcAPL6REGsBSJCzRYjsRpyDCTAFwF3icMMgTIBJAJ41EX8LYB+AdVXCBJgA0HYLyc8VITLrdRwmwDgA722cfAegH8C6QJgAEQDtRQANwFzxXhavlBPvrYcKJsAVAB0AvgBw4P8owzEAPwM4BKCwHpHezqapwGEAJwCYkq/uHx4eblRV1c0557quzwkhJhlj+n8FaQLcYG8sGPRmGXuOSbkXjHUCKN03L6X8gSnKh0KIC/8W5AaAgYEBtbmx8RUw9rLNZttUW1sLh8MBi8Vi+CkUCkin01haWkIymZSQ8ivVaj3U3d1tJm3FPKsAg4ODjmqH47TC+cNNTU2oqakBY9c/S0m+pPFsviOQaDSKbDYbAWMPCSH+qti7Ka2UkoU07Wur1bq7ra0NVqsVuq4jHo8b0eZyOV1KWeCcW0gRl8tlKEN7pqenSY1xi9W6zefzzVYKYYSoadphrijvd3R0GM5pkeOrV69S+MeT6fSriUQiWVdX12azWHZJ4CWn09lCSpEy4+PjyGSzZ/1+/56KAcLhcI3U9StNTU31FFnpWlxcJJmzYOyx3t7eb8xvoVCoXur6GZfLtaO5uRmZTIYgpAQeFEL8UgkEC4VCz6icf9LV1WWcL0laV1cHu91u2CGImZkZgugXQtBsMNalS5dcVlUddns8bdXV1ZiamsJyMnlaCEEDrOxFAGddTucukpMiiUQiGUVRrB6PR6FzLoHISGCv3+//vkSJg1UOx8eUN4lEguATvULUMcby5RKwUDA42ep2ezZv3oz5+XnMzc6ekoxd4IpyzO12K1VVVYathYUFxGKxdEHXHw0EAj/Su6Ghobscdnu0u7tboRIdGxsDV1V/T09PqHwATUt7vd5NFC2V1UI8/oYIBF4PB4PPMs4/WAsRjUbTKBT2iL6+n4oJHPd1dTlVVcXo6Ci10p1+v/98JQApr9drJ4BYLIb4wsLbQogjZCA0MnJQUdUTbreblyoRjUZTEtgthBgIh0IJn89n55wbALqU9wcCgV/LBtA07e/WlpYu6nokc3Rm5jcRCOwwDWgjI09zVf2oFIL6QywWS4Kx17iivOPz+ZDP540jyBcKvr6+PhpuZS2madopZ23tky0tLaYRXdH1+3oCgYumhXAw+BTj/GRrayunjKdVhIDT6QSVYrFkZ+/p7W1mjN001G5Hw4LB4D6V8y8pCkVRMDs7i/i1axcXlpZ2bt++fakk4w8w4FO3262aEOTUnBWTk5NUhif9fv/BskIvbmKDg4OWqqqqcEN9/d0NDQ1GZyNjqVRqSJdyfyAQCK4eh6btVxj7rBSCvqVSKUxMTBR0Ke8t3V8OiNGKg8HgLq4oZ7xeL6MGRD1+bm6OciIvdZ1+VC5IKROKorQTlM1mc1HbJsWo/CKRCFby+eNCiOfLcVq6Z3UahjXtqML5EY/Hs9oFc7mc0WCy2awBRaVGkpuTkhKPOmAmk/ljk93+QGdnZ8U/rqsANBHDmvYWU5QXGhoaGM0FivBWi45peXnZKNt8Pn9+JZ/fs2XLlnil0dP+m/6IRjXtER14l3PeTt3RTDKaEysrK0a7LqqShJRHk+n0m1u3bl25E+e3BKCXly9ftuVyuX7GWD8DtgFoBKBIKRcB/AnGzlmt1s/vZP6vBf0HMZ1lP+1/xj0AAAAASUVORK5CYII=&quot;) 1 0, pointer !important;">
                        </i>
                      </div>

                      <div class="text-normal-gray" data-v-a81ebbe4>Tải ảnh lên

                      </div>
                    </div>
                  </div>
                  <div class="list-medias" data-v-a81ebbe4>
                    <div data-v-2345b636 data-v-a81ebbe4>
                      <div class="media-wrapper row" data-v-2345b636>
                        <div data-v-2345b636 style="margin-right: 10px; position: relative;">
                          
                            <img scr="" id="image" width="calc(100% - 130px)" height="130px" max-width="515px" >
                            <input type="file" name="ANH_BAIDANG" id="imageFile" 
                            accept="image/png, image/jpg, image/jpeg" multiple="multiple" style="width: auto" data-v-a81ebbe4 onchange="chooseFile(this)">
                          
                        </div>
                      </div>
                    </div>
                  </div><!---->
                </div>
              </div>
              <div class="right-content mt-1" data-v-a81ebbe4>
                <div class="ratting-content" data-v-a81ebbe4>
                  <h2 class="text-normal-gray font-weight-bold" style="font-size: 20px" data-v-a81ebbe4>Đánh giá</h2>
                  <div class="line" data-v-a81ebbe4>
  
                  </div>
                  <div class="ratting-info" data-v-a81ebbe4>
                    <div class="item-rating" data-v-a81ebbe4>
                      <div class="text-normal-black d-inline-block" data-v-a81ebbe4>
                        <b data-v-a81ebbe4>Tổng thể</b>
                      </div>
                      <div class="ratting-star" data-v-a81ebbe4>
                        <div class="stars">
                          
                            <input class="star star-5" id="star-5" type="radio" name="star" value="5"/>
                            <label class="star star-5" for="star-5"></label>
                            <input class="star star-4" id="star-4" type="radio" name="star" value="4"/>
                            <label class="star star-4" for="star-4"></label>
                            <input class="star star-3" id="star-3" type="radio" name="star" value="3"/>
                            <label class="star star-3" for="star-3"></label>
                            <input class="star star-2" id="star-2" type="radio" name="star" value="2"/>
                            <label class="star star-2" for="star-2"></label>
                            <input class="star star-1" id="star-1" type="radio" name="star" value="1"/>
                            <label class="star star-1" for="star-1"></label>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="control-content" data-v-a81ebbe4>
                                    <button name="sbm" class="btn-post btn-color-primary text-normal-gray sweezy-custom-cursor-hover" data-v-a81ebbe4="" type="submit">Đăng</button>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
                              </form>
    </div>
  </div>
  <footer>
    <div class="container-footer">
        <div class="footer-content container">
            <div class="footer-info">
                <div class="float-left">
                    <i class="icon-riviu-footer float-left"></i>
                    <div class="text-normal-black text-nowrap">Ăn khắp nơi chơi khắp chốn</div>
                </div> 
                <div class="float-right">
                    <a href="/about" class="">
                        <h4 class="text-item-hover">Về chúng tôi</h4>
                    </a> 
                    <a href="/lien-he" target="_blank" class="">
                        <h4 class="text-item-hover">Liên hệ</h4>
                    </a> <a href="/policy" target="_blank" class="">
                        <h4 class="text-item-hover">Chính sách</h4>
                    </a>
                </div>
            </div>
            <div class="line"></div>
            <div class="footer-description text-normal-gray">© Công Ty TNHH RIVICO  •  Địa chỉ: 372-374 Trần Hưng Đạo, Phường 2, Quận 5, HCM  •  Số điện thoại: 091 5650550  •  Mã số thuế: 0316141166 
        Giấy phép thiết lập MXH số 528/GP-BTTTT , Ký ngày : 17/11/2020 cấp bởi Bộ thông tin và truyển thông • Email: contact@riviu.vn 
        • Người chịu trách nhiệm nội dung: Lê Đình Thái</div>
    </div> 
    </footer>
  
  
  
  
  
  
  
  
  
              