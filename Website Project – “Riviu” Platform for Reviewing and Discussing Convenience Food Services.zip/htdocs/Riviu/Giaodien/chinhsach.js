document.addEventListener('DOMContentLoaded', function() {
    // Initially display the English content
    switchLanguage('vietnamese');
});

function switchLanguage(language) {
    const englishContent = document.getElementById('english');
    const vietnameseContent = document.getElementById('vietnamese');
    const btnEnglish = document.getElementById('btn-english');
    const btnVietnamese = document.getElementById('btn-vietnamese');
    
    if (language === 'english') {
        englishContent.style.display = 'block';
        vietnameseContent.style.display = 'none';
        btnEnglish.style.backgroundColor = 'orange';  // Change to your desired color
        btnEnglish.style.color = 'white';
        btnVietnamese.style.backgroundColor = '';   // Reset to default color
        btnVietnamese.style.color = '';
    } else if (language === 'vietnamese') {
        englishContent.style.display = 'none';
        vietnameseContent.style.display = 'block';
        btnVietnamese.style.backgroundColor = 'orange';  // Change to your desired color
        btnVietnamese.style.color = 'white';
        btnEnglish.style.backgroundColor = '';   // Reset to default color
        btnEnglish.style.color = '';
    }
}
