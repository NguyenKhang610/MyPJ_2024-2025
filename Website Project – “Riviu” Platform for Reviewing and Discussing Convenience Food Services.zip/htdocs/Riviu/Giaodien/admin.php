<?php
    if(!isset($_SESSION['currAdmin'])){
        ?>
        <a href="login.php">Dang nhap</a>
        <?php
    }
    else {
        echo "xin chao:".$_SESSION['currAdmin'];
        echo "<a href='logout.php'>Thoat</a>";
    }
?>
Trang chu