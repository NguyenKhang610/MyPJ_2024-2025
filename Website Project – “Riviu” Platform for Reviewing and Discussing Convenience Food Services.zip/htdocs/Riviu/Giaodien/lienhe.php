<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Liên hệ</title>
  <link rel="stylesheet" href="lienhe.css">
</head>
<body style="margin-top:50px">
    <div class="main">
        <h1 style="padding-bottom: 30px">Liên hệ </h1>
      <div class="khung">
        <p style = "color: rgb(247, 134, 22); font-weight: bold"> Rivico 2020. Công ty TNHH Rivico </p> 
        <p><strong>Email:</strong> contact@riviu.vn</p>
        <p><strong>Phone:</strong> 091 5650550</p>
        <p><strong>Địa chỉ:</strong> 372 - 374 Trần Hưng Đạo, P.2, Quận 5, TP. Hồ Chí Minh </p>
        <p><strong>GPDKKD:</strong> 0316141166 do Sở KH&DT TP. HCM cấp ngày 14/02/2020</p>
      </div>
      <div class="image">
          <img src="trangphu\image\lienhe\lienhe.png" alt="Ảnh công ty">
      </div>
    </div>
  </body>
  </html>
  <?php 
  require_once 'footer.php';
  ?>


  