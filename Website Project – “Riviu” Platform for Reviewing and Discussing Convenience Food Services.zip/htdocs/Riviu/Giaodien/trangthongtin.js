document.addEventListener('DOMContentLoaded', function() {
    transform('baiviet');
});

function transform(trans) {
    const content = document.getElementById('baiviet');
    const picture = document.getElementById('anh');
    const btnContent = document.getElementById('btn-baiviet');
    const btnPicture = document.getElementById('btn-anh');
    
    if (trans === 'baiviet') {
        content.style.display = 'block';
        picture.style.display = 'none';
        btnContent.style.backgroundColor = 'orange'; 
        btnContent.style.color = 'white';
        btnPicture.style.backgroundColor = '';   
        btnPicture.style.color = '';
    } else if (trans === 'anh') {
        content.style.display = 'none';
        picture.style.display = 'block';
        btnPicture.style.backgroundColor = 'orange';  
        btnPicture.style.color = 'white';
        btnContent.style.backgroundColor = '';   
        btnContent.style.color = '';
    }
}
