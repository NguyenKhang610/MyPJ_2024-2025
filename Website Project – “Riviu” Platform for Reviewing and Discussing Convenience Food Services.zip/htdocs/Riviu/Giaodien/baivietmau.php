<?php
$conect = mysqli_connect('localhost', 'root', '', 'doantienloi');
if ($conect) {
    mysqli_query($conect, "Set NAMES 'UTF8'");
} else {
    echo "Kết nối thất bại";
}
include "header.php";
?>
<?php
$id_user = $_SESSION["ID_DANGNHAP"];
$sql_user = "SELECT * FROM account where ID_DANGNHAP = '$id_user'";
$query_user = mysqli_query($conect, $sql_user);
$row_user = mysqli_fetch_assoc($query_user);
$id = $_GET['id'];
$sql = "SELECT * FROM quanlybaidang where ID_BAIDANG = '$id'";
$query = mysqli_query($conect, $sql);
$row_up = mysqli_fetch_assoc($query);
$row_up_nv = $row_up["ID_NGUOIDANG"];
$sql_nv = "SELECT * FROM account where ID_DANGNHAP = '$row_up_nv'";
$query_nv = mysqli_query($conect, $sql_nv);
$row_nv = mysqli_fetch_assoc($query_nv);
$sql_bl = "SELECT * FROM quanlybinhluan";
$query_bl = mysqli_query($conect, $sql_bl);

?>
<?php
    $sql_bl = "SELECT * FROM quanlybinhluan";
    $query_bl = mysqli_query($conect, $sql_bl);

    if(isset($_POST['sbm'])){
        $noiDungBinhLuan = $_POST['comment'];
        $ngay = date('Y-m-d');
        $gio = date('H:i:s');

        $sql_bl = "INSERT INTO quanlybinhluan (NOIDUNG_BINHLUAN, NGAY_BINHLUAN, GIO_BINHLUAN, ID_BAIDANG, ID_NGUOIDUNG)
        VALUES ('$noiDungBinhLuan', '$ngay', '$gio', '$id', '$id_user')";
        $query_bl = mysqli_query($conect, $sql_bl);
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $row_up['TIEUDE_BAIDANG']?></title>
    <link rel="stylesheet" href="baivietmau.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <script>

        var input = document.querySelector('.pswrd');
		var show = document.querySelector('.show');
		show.addEventListener('click', active);
		function active(){
			if(input.type === "password"){
				input.type = "text";
				show.style.color = "#1DA1F2";
				show.textContent = "HIDE";
			}else{
				input.type = "password";
				show.textContent = "SHOW";
				show.style.color = "#111";
			}
		}
	
	</script>
</head>
<body>

    <main>
        <div class="review">
            <div class="reviewer">
                <div class="profile-avatar">
                    <img src="trangphu/Ảnh/<?php echo $row_nv["ANH"]  ?>" alt="Ảnh đại diện" class="avatar">
                </div>
                <div class="profile-info">
                    <h3 style="color: black"><?php echo $row_nv["HOTEN"]; ?></h3>
                    <p style="color: black"> Đã đăng vào lúc <?php echo $row_up["GIO_BAIDANG"]; ?>  <?php echo $row_up["NGAY_BAIDANG"]; ?></p>
                </div>
                <div class="baocao">
                    <a href="file:///E:/Riviu/code/baocao.html">...</a>
                </div>
            </div>
            <div class="top">
                <div class="main">
                    <img src="image\maubaiviet\mau1.jpg" class="img-feature"/>
                    <div class="control prev"><i class='bx bx-chevron-left' ></i></div>
                    <div class="control next"><i class='bx bx-chevron-right' ></i></div>
                </div>
                <div class="list-image">
                    <div><img src="image\maubaiviet\05.jpg" alt=""></div>
                    <div><img src="image\maubaiviet\05.jpg" alt=""></div>
                    <div><img src="image\maubaiviet\05.jpg" alt=""></div>
                </div>
            </div>

            <script src="baivietmau.js"></script>
    
            <div class="rating">
                <img src="image/maubaiviet/iconrate.png" alt="iconrate" class="icon">
                <span><?php echo $row_up["DANHGIA"] ?>.0/5 điểm</span>
            </div>

            <div class="review-content">
                <h3 class="rv"> <?php echo $row_up["TIEUDE_BAIDANG"] ?></h3>
                <p>Đánh giá sản phẩm: <?php echo $row_up["NOIDUNG_BAIDANG"] ?></p>
            </div>
            <div class="other">
                <div class="tym">
                    <div class="heart-container" title="Like">
                        <input type="checkbox" class="checkbox" id="Give-It-An-Id">
                        <div class="svg-container">
                            <svg viewBox="0 0 24 24" class="svg-outline" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.5,1.917a6.4,6.4,0,0,0-5.5,3.3,6.4,6.4,0,0,0-5.5-3.3A6.8,6.8,0,0,0,0,8.967c0,4.547,4.786,9.513,8.8,12.88a4.974,4.974,0,0,0,6.4,0C19.214,18.48,24,13.514,24,8.967A6.8,6.8,0,0,0,17.5,1.917Zm-3.585,18.4a2.973,2.973,0,0,1-3.83,0C4.947,16.006,2,11.87,2,8.967a4.8,4.8,0,0,1,4.5-5.05A4.8,4.8,0,0,1,11,8.967a1,1,0,0,0,2,0,4.8,4.8,0,0,1,4.5-5.05A4.8,4.8,0,0,1,22,8.967C22,11.87,19.053,16.006,13.915,20.313Z">
                                </path>
                            </svg>
                            <svg viewBox="0 0 24 24" class="svg-filled" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.5,1.917a6.4,6.4,0,0,0-5.5,3.3,6.4,6.4,0,0,0-5.5-3.3A6.8,6.8,0,0,0,0,8.967c0,4.547,4.786,9.513,8.8,12.88a4.974,4.974,0,0,0,6.4,0C19.214,18.48,24,13.514,24,8.967A6.8,6.8,0,0,0,17.5,1.917Z">
                                </path>
                            </svg>
                            <svg class="svg-celebrate" width="100" height="100" xmlns="http://www.w3.org/2000/svg">
                                <polygon points="10,10 20,20"></polygon>
                                <polygon points="10,50 20,50"></polygon>
                                <polygon points="20,80 30,70"></polygon>
                                <polygon points="90,10 80,20"></polygon>
                                <polygon points="90,50 80,50"></polygon>
                                <polygon points="80,80 70,70"></polygon>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="cmt">
                    <span style="font-weight: bold;">3 bình luận</span>
                </div>
            </div>

            <div class="comment">
                <div class="cmt-avatar">
                    <img src="trangphu/Ảnh/<?php echo $row_user['ANH']; ?>" alt="Ảnh đại diện" class="avt-cmt">
                </div>
            <form id="myForm" action="baivietmau.php?page_layout=baivietmau&id=<?php echo $id;?>" method="POST" style="position: relative;
            width: fit-content;">
                <div class="mb-3">
                    <input type="text" style="width:900px; height: 50px; display: block;" class="form-control" id="textInput"  name="comment" id="" placeholder="Viết bình luận...">
                    <span class="show" id="submitIcon" style="display: none;position: absolute;top: 40%;right: 10px;transform: translateY(-50%); cursor: pointer; display: block;"><Button name="sbm" type="submit" style="border-color:white;background-color: orange; color:white;">Gửi</Button></span>
                </div>
                </form>
                
            </div>
            
    <div class="comment-section">
    <?php
     while ($row_bl = mysqli_fetch_assoc($query_bl)){
            if($row_bl["ID_BAIDANG"] == $id){
                $id_nguoidung = $row_bl["ID_NGUOIDUNG"];
                $sql_ngdung = "SELECT * FROM account WHERE ID_DANGNHAP = '$id_nguoidung'";
                $query_ngdung = mysqli_query($conect, $sql_ngdung);
                $row_ngdung = mysqli_fetch_assoc($query_ngdung);
                ?> 
        <div class="comment" >
        
            <div class="cmt-avatar">
                <img style="width: 60px;
    height: 60px;
    border-radius: 50%;" src="trangphu/Ảnh/<?php echo $row_ngdung['ANH']; ?>" alt="User Avatar">
            </div>
            <div class="comment-body">
                <div class="comment-header">
                    <span class="comment-author" style="color:orange; font-weight:bold;"><?php echo $row_ngdung["HOTEN"]; ?></span>
                    <span class="comment-time" style="color:gray; font-size:12px;">Đã bình luận vào <?php echo $row_bl["GIO_BINHLUAN"] ?></span>
                </div>
                <div class="comment-text">
                    <?php echo $row_bl["NOIDUNG_BINHLUAN"] ?>
                </div>
            </div>
            
        </div><?php
            } ?>
            
           
        <?php } ?>
        
        
    </div>
</body>
</html>

    
        </div>
    </main>
    <script src="baivietmau1.js"></script>
</body>
</html>
<?php
include "footer.php";
?>