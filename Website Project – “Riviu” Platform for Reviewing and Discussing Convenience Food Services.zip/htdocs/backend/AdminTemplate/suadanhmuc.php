<?php
include "header.php";
include "leftsign.php";
?>
<?php
    $id = $_GET['id'];

    $sql_up = "SELECT * FROM quanlydanhmuc where ID_DANHMUC = $id";

    $query_up = mysqli_query($conect, $sql_up);
    $row_up = mysqli_fetch_assoc($query_up);

    if(isset($_POST['sbm'])){
        $names = $_POST['TEN_DANHMUC'];
        if($_FILES['ANH_DANHMUC']['name']=='')
        {
            $image = $row_up['ANH_DANHMUC'];
           
        }
        else{
            $image = $_FILES['ANH_DANHMUC']['name'];
            $image_tmp = $_FILES['ANH_DANHMUC']['tmp_name'];
            move_uploaded_file($image_tmp, 'E:/xampp/htdocs/backend/AdminTemplate/img/'.$image);
        }

        
    $sql = "UPDATE quanlydanhmuc SET ANH_DANHMUC = '$image', TEN_DANHMUC = '$names' WHERE ID_DANHMUC = $id ";
    $query = mysqli_query($conect, $sql);
    
    header('location: danhmuc.php?page_layout=quanlydanhmuc');

    }
?>

<div class="content">
    <div class="card">
        <div class="card-header">
            <h2>Sửa</h2>
        </div>
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data" >
                <div class="mb-3">
                    <label for="TEN_DANHMUC"class="form-label">Người đăng</label>
                    <input type="text" name="TEN_DANHMUC" class="form-control" id="TEN_DANHMUC" required value = "<?php echo $row_up['TEN_DANHMUC'];?>">
                </div>

                <div class="col" align="center">
                    <label for="ANH_DANHMUC">Ảnh</label>
                    <input type="file" name="ANH_DANHMUC"  class="form-control" id="ANH_DANHMUC" value = "<?php echo $row_up['ANH_DANHMUC']; ?>">
                </div>
                <button style="margin-top:20px;" onclick="return Edi()" name="sbm" class="btn btn-success" type="submit">Sửa</button>
            </form>
        </div>
    </div>
</div>
<script>
    function Edi()
    {
        return confirm("Xác nhận lưu thay đổi?");
    }

</script>