<?php
    $id = $_GET['id'];
    $sql = "DELETE FROM quanlyuudai where ID = $id";
    $query = mysqli_query($conect, $sql);
    header('location: uudai.php?page_layout=quanlydanhsachuudai');
?>
