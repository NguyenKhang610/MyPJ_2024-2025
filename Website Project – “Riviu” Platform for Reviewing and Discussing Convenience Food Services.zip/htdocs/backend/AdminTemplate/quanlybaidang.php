<?php
    $conect = mysqli_connect('localhost','root','','doantienloi');
    if($conect)
    {
        mysqli_query($conect, "Set NAMES 'UTF8'");
    }
    else{
        echo "Kết nối thất bại";
    }
?>
<?php
include "header.php";
include "leftsign.php";
?>
    <!-- PHẦN SIDEBAR END -->
    <!-- PHẦN NỘI DUNG QUẢN LÝ -->
<?php
    $sql = "SELECT * FROM quanlybaidang ORDER BY ID_BAIDANG DESC";
    $query = mysqli_query($conect, $sql);
?>
<div class="content">
    <div class="card">
        <div class="card-header">
            <h2 style="text-align: center;">Danh sách bài viết</h2>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID bài viế<table></table></th>
                        <th>Tiêu đề</th>
                        <th>Nội Dung</th>
                        <th>Ngày đăng</th>
                        <th>Giờ</th>
                        <th>Đánh giá</th>
                        <th>Người viết</th>
                        <th>Xóa</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    while ($row = mysqli_fetch_assoc($query)){
                     ?>
                    
                        <tr>
                            <td><?php echo $row['ID_BAIDANG']; ?></td>
                            <td><?php echo $row['TIEUDE_BAIDANG']; ?></td>
                            <td><?php echo $row['NOIDUNG_BAIDANG']; ?></td>
                            <td><?php echo $row['NGAY_BAIDANG']; ?></td>
                            <td><?php echo $row['GIO_BAIDANG']; ?></td>
                            <td><?php echo $row['DANHGIA']; ?></td>
                            <td><?php $id=$row['ID_NGUOIDANG'];
                            $sql_up = "SELECT * FROM account WHERE ID_DANGNHAP = '$id' ";
                            $query_up = mysqli_query($conect, $sql_up);
                            $row_up = mysqli_fetch_assoc($query_up);
                            echo $row_up["HOTEN"];
                            
                            ?></td>
                            <td> <a onclick="return Del()" href="baidang.php?page_layout=xoabaidang&id=<?php echo $row['ID_BAIDANG']; ?>">Xóa</td>
                        </tr>
                    <?php }
                    ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function Del(){
        return confirm("Bạn có chắc muốn xóa không?");
    }
</script>