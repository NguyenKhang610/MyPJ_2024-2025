<?php
    $id = $_GET['id'];
    $sql = "DELETE FROM account where ID_DANGNHAP = $id";
    $query = mysqli_query($conect, $sql);
    header('location: nguoidung.php?page_layout=quanlynguoidung');
?>
