<?php
    $id = $_GET['id'];
    $sql = "DELETE FROM user where ID = $id";
    $query = mysqli_query($conect, $sql);
    header('location: datban.php?page_layout=quanlydatban');
?>
