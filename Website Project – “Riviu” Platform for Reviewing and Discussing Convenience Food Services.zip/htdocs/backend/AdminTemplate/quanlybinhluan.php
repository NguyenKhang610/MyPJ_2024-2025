<?php
    $conect = mysqli_connect('localhost','root','','doantienloi');
    if($conect)
    {
        mysqli_query($conect, "Set NAMES 'UTF8'");
    }
    else{
        echo "Kết nối thất bại";
    }
?>
<?php
include "header.php";
include "leftsign.php";
?>
    <!-- PHẦN SIDEBAR END -->
    <!-- PHẦN NỘI DUNG QUẢN LÝ -->
<?php
    $sql = "SELECT * FROM quanlybinhluan ORDER BY ID_BINHLUAN DESC";
    $query = mysqli_query($conect, $sql);
?>
<div class="content">
    <div class="card">
        <div class="card-header">
            <h2 style="text-align: center;">Danh sách bình luận</h2>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>Link bài viết</th>
                        <th>Người bình luận</th>
                        <th>Nội dung</th>
                        <th>Ngày</th>
                        <th>Giờ</th>
                        <th>Xóa</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    while ($row = mysqli_fetch_assoc($query))
                    { ?>
                    
                        <tr>
                            <td><a href="Riviu/Giaodien/baivietmau.php?page_layout=baivietmau&id=<?php echo $row["ID_BAIDANG"]; ?>">Link</a></td>
                            <td><?php $id=$row['ID_NGUOIDUNG'];
                            $sql_up = "SELECT * FROM account WHERE ID_DANGNHAP = '$id' ";
                            $query_up = mysqli_query($conect, $sql_up);
                            $row_up = mysqli_fetch_assoc($query_up);
                            echo $row_up["HOTEN"];
                            
                            ?></td>
                            <td><?php echo $row['NOIDUNG_BINHLUAN']; ?></td>
                            <td><?php echo $row['NGAY_BINHLUAN']; ?></td>
                            <td><?php echo $row['GIO_BINHLUAN']; ?></td>
                            <td> <a onclick="return Del()" href="binhluan.php?page_layout=xoabinhluan&id=<?php echo $row['ID_BINHLUAN']; ?>">Xóa</td>
                        </tr>
                    <?php }
                    ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function Del(){
        return confirm("Bạn có chắc muốn xóa không?");
    }
</script>