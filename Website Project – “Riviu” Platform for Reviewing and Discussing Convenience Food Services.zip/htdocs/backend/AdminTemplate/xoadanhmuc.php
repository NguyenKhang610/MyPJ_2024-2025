<?php
    $id = $_GET['id'];
    $sql = "DELETE FROM quanlydanhmuc where ID_DANHMUC = $id";
    $query = mysqli_query($conect, $sql);
    header('location: danhmuc.php?page_layout=quanlydanhmuc');
?>
