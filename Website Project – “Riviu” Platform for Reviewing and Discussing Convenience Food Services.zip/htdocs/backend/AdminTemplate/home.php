<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin GangBuk</title>
    <link rel="shortcut icon" type="image/png" href="img/logo.png" />
    <link rel="stylesheet" href="main.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!-- CSS only -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css"
    />
  </head>
  <body>
    <input type="checkbox" id="check" />
    <!-- PHẦN HEADER START -->
    <header>
      <label for="check"><i class="fas fa-bars" id="sidebar_btn"></i></label>
      <div class="left-area">
        <h3>Admin <span style="color:orange;">Management</span></h3>
      </div>
      <div class="right-area">
        <a href="logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!-- PHẦN HEADER END -->

    <!-- PHẦN SIDEBAR RESPONSIVE START -->
    <div class="mobile_nav">
      <div class="nav_bar">
        <img src="img/avatar.png" class="mobile_profile_image" alt="" />
        <i class="fas fa-bars nav_btn"></i>
      </div>
      <div class="mobile_nav_items">
      <a href="home.php"><i class="fas fa-home"></i><span>Trang chủ</span></a>
      <a href="quanlynguoidung.php"><i class="fas fa-users"></i><span>Quản lý người dùng</span></a>
      <a href="quanlybaidang.php"><i class="fas fa-pen"></i><span>Quản lý bài đăng</span></a>
      <a href="quanlydanhmuc.php"><i class="fas fa-pen"></i><span>Quản lý danh mục</span></a>
      <a href="quanlybinhluan.php"><i class="fas fa-pen"></i><span>Quản lý bình luận</span></a>
    </div>
    </div>
    <!-- PHẦN SIDEBAR RESPONSIVE END -->

    <!-- PHẦN SIDEBAR START -->
    <div class="sidebar">
      <div class="profile_info">
        <img src="img/avatar.png" class="profile_image" alt="" />
        <h4>Admin</h4>
      </div>
      <a href="home.php"><i class="fas fa-home"></i><span>Trang chủ</span></a>
      <a href="quanlynguoidung.php"><i class="fas fa-users"></i><span>Quản lý người dùng</span></a>
      <a href="quanlybaidang.php"><i class="fas fa-pen"></i><span>Quản lý bài đăng</span></a>
      <a href="quanlydanhmuc.php"><i class="fas fa-pen"></i><span>Quản lý danh mục</span></a>
      <a href="quanlybinhluan.php"><i class="fas fa-pen"></i><span>Quản lý bình luận</span></a>
    </div>
    </div>
    <!-- JAVASCRIPT -->
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="main.js"></script>
  </body> 
</html>
