<?php
        $conect = mysqli_connect('localhost','root','','doantienloi');
        if($conect)
        {
            mysqli_query($conect, "Set NAMES 'UTF8'");
        }
        else{
            echo "Kết nối thất bại";
        }
?>
<?php
include "header.php";
include "leftsign.php";
?>
    <!-- PHẦN SIDEBAR END -->
    <!-- PHẦN NỘI DUNG QUẢN LÝ -->
    <?php
    $sql_mg = "SELECT * FROM quanlydanhmuc";
    $query_mg = mysqli_query($conect, $sql_mg);

    if(isset($_POST['sbm'])){
        $names = $_POST['TEN_DANHMUC'];

        $image = $_FILES['ANH_DANHMUC']['name'];
        $image_tmp = $_FILES['ANH_DANHMUC']['tmp_name'];

        $sql = "INSERT INTO quanlydanhmuc (ANH_DANHMUC, TEN_DANHMUC)
        VALUES ('$image', '$names')";
        $query = mysqli_query($conect, $sql);
        move_uploaded_file($image_tmp, 'E:/xampp/htdocs/backend/AdminTemplate/img/'.$image);
        header('location: danhmuc.php?page_layout=quanlydanhmuc');

    }
?>

<div class="content">
    <div class="card">
        <div class="card-header">
            <h2 style="text-align: center;">Thêm danh mục</h2>
        </div>
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data" >
                <div class="mb-3">
                    <label for="TEN_DANHMUC" class="form-label">Tên danh mục</label>
                    <input type="text" name="TEN_DANHMUC" class="form-control" id="TEN_DANHMUC" required>
                </div>

                <div class="col" align="center">
                    <label for="ANH_DANHMUC">Ảnh danh mục:</label>
                    <input type="file" name="ANH_DANHMUC" id="ANH_DANHMUC" class="form-control" required>
                </div>
                <button style="margin-top:20px;" name="sbm" class=" btn btn-success" type="submit">Thêm</button>
            </form>
        </div>
    </div>
</div>
<?php
    $sql = "SELECT * FROM quanlydanhmuc ORDER BY ID_DANHMUC DESC";
    $query = mysqli_query($conect, $sql);
?>
<div class="content">
    <div class="card">
        <div class="card-header">
            <h2 style="text-align: center;">Danh sách danh mục</h2>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID danh mục</th>
                        <th>Tên danh mục</th>
                        <th>Sửa</th>
                        <th>Xóa</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    while ($row = mysqli_fetch_assoc($query)){ ?>
                        <tr>
                            <td><?php echo $row['ID_DANHMUC']; ?></td>
                            <td><?php echo $row['TEN_DANHMUC']; ?></td>
                            <td> <a href="danhmuc.php?page_layout=suadanhmuc&id=<?php echo $row['ID_DANHMUC']; ?>">Sửa</a> </td>
                            <td> <a onclick="return Del()" href="danhmuc.php?page_layout=xoadanhmuc&id=<?php echo $row['ID_DANHMUC']; ?>">Xóa</td>
                        </tr>
                    <?php }
                    ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function Del(){
        return confirm("Bạn có chắc muốn xóa không?");
    }
</script>