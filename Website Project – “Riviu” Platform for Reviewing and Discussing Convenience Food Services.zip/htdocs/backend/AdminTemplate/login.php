<!DOCTYPE html>
<html>
<head>
    <title>Admin GangBuk</title>
    <link rel="stylesheet" href="login_admin.css" />
    <link rel="shortcut icon" type="image/png" href="img/logo.png" />
</head>
<body>
    <div class="container" id="container">
        <div class="form-container sign-in-container">
            <form action="adminaction.php" method="post">
                <h1 style="padding-bottom: 8px;">Đăng nhập</h1>
                <input type="email" id="" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" style="margin-bottom: 15px;" required>
                <button type="submit" name="dangnhap">Đăng nhập</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-right">
                    <h1>GangBuk!</h1>
                    <p>Chào mừng bạn đến với, gangbuk</p>
                </div>
            </div>
        </div>
    </div>
</body>

</html>