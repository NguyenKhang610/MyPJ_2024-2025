<?php
    $conect = mysqli_connect('localhost','root','','doantienloi');
    if($conect)
    {
        mysqli_query($conect, "Set NAMES 'UTF8'");
    }
    else{
        echo "Kết nối thất bại";
    }
?>
<?php
include "header.php";
include "leftsign.php";
?>
    <!-- PHẦN SIDEBAR END -->
    <!-- PHẦN NỘI DUNG QUẢN LÝ -->
<?php
    $sql = "SELECT * FROM account ORDER BY ID_DANGNHAP DESC";
    $query = mysqli_query($conect, $sql);
?>
<div class="content">
    <div class="card">
        <div class="card-header">
            <h2 style="text-align: center;">Danh sách tài khoản</h2>
        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Ảnh đại diện</th>
                        <th>Họ tên</th>
                        <th>Email</th>
                        <th>Mật khẩu</th>
                        <th>Số điện thoại</th>
                        <th>Role</th>
                        <th>Xóa</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    while ($row = mysqli_fetch_assoc($query))
                    if($row['ROLE'] == 'User'){ ?>
                    
                        <tr>
                            <td><?php echo $row['ID_DANGNHAP']; ?></td>
                            <td><img src="<?php echo $row['ANH']; ?>"style="width:100px; height:100px; clip-path: circle(50px at 50% 50%);"></td>
                            <td><?php echo $row['HOTEN']; ?></td>
                            <td><?php echo $row['EMAIL']; ?></td>
                            <td><?php echo $row['MATKHAU']; ?></td>
                            <td><?php echo $row['SODIENTHOAI']; ?></td>
                            <td><?php echo $row['ROLE']; ?></td>
                            <td> <a onclick="return Del()" href="nguoidung.php?page_layout=xoanguoidung&id=<?php echo $row['ID_DANGNHAP']; ?>">Xóa</td>
                        </tr>
                    <?php }
                    ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function Del(){
        return confirm("Bạn có chắc muốn xóa không?");
    }
</script>