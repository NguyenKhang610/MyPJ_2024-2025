let inputName = document.getElementById("inputName");
let inputTitle = document.getElementById("inputTitle");
let inputContent = document.getElementById("inputContent");
let inputDate = document.getElementById("inputDate");
let inputPic = document.getElementById("inputPic");
let inputSearch = document.getElementById("inputSearch");
let alertName = document.getElementById("alertName");
let alertTitle = document.getElementById("alertTitle");
let alertContent = document.getElementById("alertContent");
let alertDate = document.getElementById("alertDate");
let alertPic = document.getElementById("alertPic");
let btnAdd = document.getElementById("btnAdd");
let btnClear = document.getElementById("btnClear");
let tableBody = document.getElementById("tableBody");
let currentIndex = 0;
let products = [];
if(JSON.parse(localStorage.getItem("Products")) !== null){
    products = JSON.parse(localStorage.getItem("Products"));
    displayProduct();
}
btnAdd.addEventListener("click",_=>{
    if(validName() && validTitle() && validContent() && validDate() && validPic()){
        if(btnAdd.innerHTML === "Add Product"){
            let product = {
                name: inputName.value,
                title: inputTitle.value,
                content: inputContent.value,
                date: inputDate.value,
                pic: inputPic.value
            };
            products.push(product)
            localStorage.setItem("Products",JSON.stringify(products))
            displayProduct()
            clearForm()
            inputName.classList.remove("is-valid")
            inputTitle.classList.remove("is-valid")
            inputContent.classList.remove("is-valid")
            inputDate.classList.remove("is-valid")
            inputPic.classList.remove("is-valid")
        } else if(btnAdd.innerHTML === "Update Product"){
            updateProduct()
            clearForm()
            inputName.classList.remove("is-valid")
            inputTitle.classList.remove("is-valid")
            inputContent.classList.remove("is-valid")
            inputDate.classList.remove("is-valid")
            inputPic.classList.remove("is-valid")
            
        }
    }
})
function displayProduct(){
    let temp = "";
    for(let i=0;i<products.length;i++){
        temp += `
        <tr>
            <td>${i + 1}</td>
            <td>${products[i].name}</td>
            <td>${products[i].title}</td>
            <td>${products[i].content}</td>
            <td>${products[i].date}</td>
            <td>${products[i].pic}</td>
            <td>
                <i onclick="getProductInformation(${i})" title="Update" class="fa-solid me-2 text-warning fa-pen"></i>
                <i onclick="deleteProduct(${i})" title="Delete" class="fa-solid text-danger fa-trash"></i>
            </td>
        </tr>`
    }
    tableBody.innerHTML = temp
}
btnClear.addEventListener("click",clearForm)
function clearForm(){
    inputName.value = ""
    inputTitle.value = ""
    inputContent.value = ""
    inputDate.value = ""
    inputPic.value = ""
    inputName.classList.remove("is-valid")
    inputName.classList.remove("is-invalid")
    alertName.classList.replace("d-block","d-none")
    inputTitle.classList.remove("is-valid")
    inputTitle.classList.remove("is-invalid")
    alertTitle.classList.replace("d-block","d-none")
    inputContent.classList.remove("is-valid")
    inputContent.classList.remove("is-invalid")
    alertContent.classList.replace("d-block","d-none")    
    inputDate.classList.remove("is-valid")
    inputDate.classList.remove("is-invalid")
    alertDate.classList.replace("d-block","d-none")
    inputPic.classList.remove("is-valid")
    inputPic.classList.remove("is-invalid")
    alertPic.classList.replace("d-block","d-none")
}
function getProductInformation(index){
    currentIndex = index
    inputName.value = products[currentIndex].name
    inputTitle.value = products[currentIndex].title
    inputContent.value = products[currentIndex].content
    inputDate.value = products[currentIndex].date
    inputPic.value = products[currentIndex].pic
    btnAdd.classList.replace("btn-success","btn-warning")
    btnAdd.innerHTML = "Update Product"
    inputName.classList.remove("is-invalid")
    alertName.classList.replace("d-block","d-none")
    inputTitle.classList.remove("is-invalid")
    alertTitle.classList.replace("d-block","d-none")
    inputContent.classList.remove("is-invalid")
    alertContent.classList.replace("d-block","d-none")    
    inputDate.classList.remove("is-invalid")
    alertDate.classList.replace("d-block","d-none")
    inputPic.classList.remove("is-invalid")
    alertPic.classList.replace("d-block","d-none")
}
function updateProduct(){
    let product = {
        name: inputName.value,
        title: inputTitle.value,
        content: inputContent.value,
        date: inputDate.value,
        pic: inputPic.value
    };
    products[currentIndex] = product
    displayProduct()
    localStorage.setItem("Products",JSON.stringify(products))
    btnAdd.classList.replace("btn-warning","btn-success")
    btnAdd.innerHTML = "Add Product"
}
function deleteProduct(index){
    products.splice(index,1)
    displayProduct()
    localStorage.setItem("Products",JSON.stringify(products))
}
inputSearch.addEventListener("keyup",_=>{
    let temp = "";
    for(let i=0;i<products.length;i++){
        if(products[i].title.toLowerCase().includes(inputSearch.value.toLowerCase())){
            temp += `
            <tr>
                <td>${i + 1}</td>
                <td>${products[i].name}</td>
                <td>${products[i].title}</td>
                <td>${products[i].content}</td>
                <td>${products[i].date}</td>
                <td>${products[i].pic}</td>
                <td>
                    <i onclick="getProductInformation(${i})" title="Update" class="fa-solid me-2 text-warning fa-pen"></i>
                    <i onclick="deleteProduct(${i})" title="Delete" class="fa-solid text-danger fa-trash"></i>
                </td>
            </tr>`
        }
    }
    tableBody.innerHTML = temp
})
inputName.addEventListener("keyup",validName)
inputTitle.addEventListener("keyup",validTitle)
inputTitle.addEventListener("keyup",validContent)
inputTitle.addEventListener("keyup",validDate)
inputTitle.addEventListener("keyup",validPic)
function validName(){
    if(inputName.value === ""){
        inputName.classList.add("is-invalid")
        inputName.classList.remove("is-valid")
        alertName.classList.replace("d-none","d-block")
        return false
    } else{
        inputName.classList.add("is-valid")
        inputName.classList.remove("is-invalid")
        alertName.classList.replace("d-block","d-none")
        return true
    }
}
function validTitle(){
    if(inputTitle.value === ""){
        inputTitle.classList.add("is-invalid")
        inputTitle.classList.remove("is-valid")
        alertTitle.classList.replace("d-none","d-block")
        return false
    } else{
        inputTitle.classList.add("is-valid")
        inputTitle.classList.remove("is-invalid")
        alertTitle.classList.replace("d-block","d-none")
        return true
    }
}
function validContent(){
    if(inputContent.value === ""){
        inputContent.classList.add("is-invalid")
        inputContent.classList.remove("is-valid")
        alertContent.classList.replace("d-none","d-block")
        return false
    } else{
        inputContent.classList.add("is-valid")
        inputContent.classList.remove("is-invalid")
        alertContent.classList.replace("d-block","d-none")
        return true
    }
}
function validDate(){
    if(inputDate.value === ""){
        inputDate.classList.add("is-invalid")
        inputDate.classList.remove("is-valid")
        alertDate.classList.replace("d-none","d-block")
        return false
    } else{
        inputDate.classList.add("is-valid")
        inputDate.classList.remove("is-invalid")
        alertDate.classList.replace("d-block","d-none")
        return true
    }
}
function validPic(){
    if(inputPic.value === ""){
        inputPic.classList.add("is-invalid")
        inputPic.classList.remove("is-valid")
        alertPic.classList.replace("d-none","d-block")
        return false
    } else{
        inputPic.classList.add("is-valid")
        inputPic.classList.remove("is-invalid")
        alertPic.classList.replace("d-block","d-none")
        return true
    }
}
