<?php
    require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <bs3-cdn:css></bs3-cdn:css>
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_GET['page_layout'])){
        switch ($_GET['page_layout']){
            case 'quanlybinhluan':
                require_once 'quanlybinhluan.php';
                break;
                        
            case 'xoabinhluan':
                require_once 'xoabinhluan.php';
                break;

            
        }
        
    }
    else{
        require_once 'quanlybinhluan.php';
    }
    ?>
</body>
</html>