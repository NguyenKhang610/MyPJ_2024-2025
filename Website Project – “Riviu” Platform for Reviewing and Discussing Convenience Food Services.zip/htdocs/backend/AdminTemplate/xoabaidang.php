<?php
    $id = $_GET['id'];
    $sql = "DELETE FROM quanlybaidang where ID_BAIDANG = $id";
    $query = mysqli_query($conect, $sql);
    header('location: baidang.php?page_layout=quanlybaidang');
?>
