<input type="checkbox" id="check" />
<!-- PHẦN HEADER START -->
<header>
  <label for="check"><i class="fas fa-bars" id="sidebar_btn"></i></label>
  <div class="left-area">
    <h3>Admin <span>Management</span></h3>
  </div>
  <div class="right-area">
    <a href="logout.php" class="logout_btn">Logout</a>
  </div>
</header>
<!-- PHẦN HEADER END -->

<!-- PHẦN SIDEBAR RESPONSIVE START -->
<div class="mobile_nav">
  <div class="nav_bar">
    <img src="img/avatar.png" class="mobile_profile_image" alt="" />
    <i class="fas fa-bars nav_btn"></i>
  </div>
  <div class="mobile_nav_items">
  <a href="home.php"><i class="fas fa-home"></i><span>Trang chủ</span></a>
      <a href="quanlynguoidung.php"><i class="fas fa-users"></i><span>Quản lý người dùng</span></a>
      <a href="quanlybaidang.php"><i class="fas fa-pen"></i><span>Quản lý bài đăng</span></a>
      <a href="quanlydanhmuc.php"><i class="fas fa-pen"></i><span>Quản lý danh mục</span></a>
      <a href="quanlybinhluan.php"><i class="fas fa-pen"></i><span>Quản lý bình luận</span></a>
  </div>
</div>
<!-- PHẦN SIDEBAR RESPONSIVE END -->

<!-- PHẦN SIDEBAR START -->
<div class="sidebar">
  <div class="profile_info">
    <img src="img/avatar.png" class="profile_image" alt="" />
    <h4>Admin</h4>
  </div>
  <a href="home.php"><i class="fas fa-home"></i><span>Trang chủ</span></a>
      <a href="quanlynguoidung.php"><i class="fas fa-users"></i><span>Quản lý người dùng</span></a>
      <a href="quanlybaidang.php"><i class="fas fa-pen"></i><span>Quản lý bài đăng</span></a>
      <a href="quanlydanhmuc.php"><i class="fas fa-pen"></i><span>Quản lý danh mục</span></a>
      <a href="quanlybinhluan.php"><i class="fas fa-pen"></i><span>Quản lý bình luận</span></a>
</div>
</div>
<!-- PHẦN SIDEBAR RESPONSIVE END -->

<!-- PHẦN SIDEBAR START -->
<div class="sidebar">
  <div class="profile_info">
    <img src="img/avatar.png" class="profile_image" alt="" />
    <h4>Admin</h4>
  </div>
  <a href="home.php"><i class="fas fa-home"></i><span>Trang chủ</span></a>
      <a href="quanlynguoidung.php"><i class="fas fa-users"></i><span>Quản lý người dùng</span></a>
      <a href="quanlybaidang.php"><i class="fas fa-pen"></i><span>Quản lý bài đăng</span></a>
      <a href="quanlydanhmuc.php"><i class="fas fa-pen"></i><span>Quản lý danh mục</span></a>
      <a href="quanlybinhluan.php"><i class="fas fa-pen"></i><span>Quản lý bình luận</span></a>
</div>
<!-- PHẦN SIDEBAR END -->
<!-- PHẦN NỘI DUNG QUẢN LÝ -->
<div class="content">
  <div class="container"></div>
</div>