<?php
    $conect = mysqli_connect('localhost','root','','doantienloi');
    if($conect)
    {
        mysqli_query($conect, "Set NAMES 'UTF8'");
    }
    else{
        echo "Kết nối thất bại";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <bs3-cdn:css></bs3-cdn:css>
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_GET['page_layout'])){
        switch ($_GET['page_layout']){
            case 'quanlynguoidung':
                require_once 'quanlynguoidung.php';
                break;
            case 'xoanguoidung':
                require_once 'xoanguoidung.php';
                break;            
        }
        
    }
    else{
        require_once 'quanlynguoidung.php';
    }
    ?>
</body>
</html>